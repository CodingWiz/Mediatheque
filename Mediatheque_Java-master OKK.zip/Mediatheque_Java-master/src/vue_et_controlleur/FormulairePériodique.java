package vue_et_controlleur;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

import Objet.Document;
import Objet.ListDocument;
import Objet.ListePeriodique;
import Objet.Periodique;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class FormulaireP�riodique extends Stage {

	String strTitre;
	String strDatePublication;
	String strMotsCles;
	String strNoVolume;
	String strNoPeriodique;

	TextField txtNoPeriodique = new TextField();
	TextField txtNoVolume = new TextField();
	TextField txtMotsCles = new TextField();
	DatePicker dpDatePublication = new DatePicker();
	TextField txtTitre = new TextField();
	SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

	public FormulaireP�riodique() {
		try {
			VBox root = createVbox();
			Scene scene = new Scene(root, 400, 400);
			// scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			this.setScene(scene);
			this.setTitle("Ajouter Nouveau P�riodique");
			this.sizeToScene();

			this.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public VBox createVbox() {

		VBox vBox = new VBox();
		vBox.setSpacing(10);
		vBox.setAlignment(Pos.CENTER);

		Label lblInfo = new Label("Veuillez rentrer les informations du p�riodique");
		lblInfo.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
		lblInfo.setAlignment(Pos.CENTER);

		vBox.getChildren().addAll(lblInfo);

		vBox.getChildren().add(createPeriodiqueVbox());

		return vBox;
	}

	public VBox createPeriodiqueVbox() {
		VBox vBox = new VBox();
		vBox.setSpacing(10);

		HBox hbox = new HBox();
		Button btnConfirmer = new Button("Confirmer");
		Button btnAnnuler = new Button("Annuler");
		hbox.setSpacing(30);
		hbox.setPadding(new Insets(30));
		btnConfirmer.setFont(new Font(20));
		btnAnnuler.setFont(new Font(20));

		btnAnnuler.setOnAction(e -> {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation");
			alert.setHeaderText("Confirmation");
			alert.setContentText("�tes vous sur de vouloir vous annuler l'ajout ?");
			alert.showAndWait().ifPresent(response -> {
				if (response == ButtonType.OK) {
					this.close();
					new BibliothequePrepose().show();
				}
			});
		});

		btnConfirmer.setOnAction(e -> {
			if (dpDatePublication.getValue() == null || txtNoPeriodique.getText().equals("")
					|| txtMotsCles.getText().equals("") || txtTitre.getText().equals("")
					|| txtNoVolume.getText().equals("")) {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("Erreur");
				alert.setHeaderText("Erreur");
				alert.setContentText("Un des champs ci-dessus n'a pas �t� rempli");
				alert.showAndWait();
			}

			else {
				strDatePublication = dpDatePublication.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				strMotsCles = txtMotsCles.getText();
				strNoPeriodique = txtNoPeriodique.getText();
				strNoVolume = txtNoVolume.getText();
				strTitre = txtTitre.getText();
				ListePeriodique.ajouterPeriodique(
						new Periodique("Per" + (ListePeriodique.getLstPeriodiqueATrouver().size() + 1), strTitre,
								strDatePublication, "Disponible", strMotsCles, strNoVolume, strNoPeriodique));
				ListDocument.ajouterDocument(new Document("Per" + (ListePeriodique.getLstPeriodiqueATrouver().size()),
						strTitre, strDatePublication, "Disponible", strMotsCles));
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Ajout");
				alert.setHeaderText("Ajout Termin�");
				alert.setContentText("Le p�riodique " + strTitre + " a �t� ajout� avec succ�s");
				alert.showAndWait();
				this.close();
				new BibliothequePrepose().show();
			}
		});

		hbox.getChildren().addAll(btnConfirmer, btnAnnuler);

		vBox.getChildren().addAll(createTitreHBox(), createDatePublicationHBox(), createNoVolumeHBox(),
				createNoPeriodiqueHBox(), createMotsClesHBox(), hbox);

		return vBox;
	}

	public String getStrTitre() {
		return strTitre;
	}

	public String getStrDatePublication() {
		return strDatePublication;
	}

	public String getStrMotsCles() {
		return strMotsCles;
	}

	public String getStrNoVolume() {
		return strNoVolume;
	}

	public String getStrNoPeriodique() {
		return strNoPeriodique;
	}

	private HBox createTitreHBox() {
		// TODO Auto-generated method stub
		HBox hBox = new HBox();
		hBox.setSpacing(10);
		hBox.setPadding(new Insets(10));

		Label lblTitre = new Label("Titre : ");
		lblTitre.setAlignment(Pos.CENTER_LEFT);

		txtTitre.setAlignment(Pos.CENTER_RIGHT);

		hBox.getChildren().addAll(lblTitre, txtTitre);

		return hBox;
	}

	private HBox createDatePublicationHBox() {
		// TODO Auto-generated method stub
		HBox hBox = new HBox();
		hBox.setSpacing(10);
		hBox.setPadding(new Insets(10));

		Label lblDatePublication = new Label("Date de publication : ");

		hBox.getChildren().addAll(lblDatePublication, dpDatePublication);

		return hBox;
	}

	private HBox createMotsClesHBox() {
		// TODO Auto-generated method stub
		HBox hBox = new HBox();
		hBox.setSpacing(10);
		hBox.setPadding(new Insets(10));

		Label lblMotsCles = new Label("Mots cl�s (s�par�s par espaces) : ");

		hBox.getChildren().addAll(lblMotsCles, txtMotsCles);

		return hBox;
	}

	private HBox createNoVolumeHBox() {
		// TODO Auto-generated method stub
		HBox hBox = new HBox();
		hBox.setSpacing(10);
		hBox.setPadding(new Insets(10));

		Label lblNoVolume = new Label("Numero du volume : ");

		hBox.getChildren().addAll(lblNoVolume, txtNoVolume);

		return hBox;
	}

	private HBox createNoPeriodiqueHBox() {
		// TODO Auto-generated method stub
		HBox hBox = new HBox();
		hBox.setSpacing(10);
		hBox.setPadding(new Insets(10));

		Label lblNoPeriodique = new Label("Numero du p�riodique : ");

		hBox.getChildren().addAll(lblNoPeriodique, txtNoPeriodique);

		return hBox;
	}

	public void lectureFichierPeriodique(String strNomFichier) {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(strNomFichier))) {
			bw.write(strMotsCles + "," + strTitre + "," + strDatePublication + ",");
			System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();

		}
	}

}
