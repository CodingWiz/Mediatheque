package vue_et_controlleur;

public class Supprimer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
